<?php
include('konekksi.php');

$email =$_POST['email'];
$password =$_POST['password'];


$lihat_user="SELECT * from user WHERE email='$email' ";
$data_user=mysql_query($lihat_user);
$data_login=mysql_fetch_array($data_user);
$email_db=$data_login['email'];
$password_db=$data_login['password'];
$id_user=$data_login['id_user'];
$nama_db=$data_login['nama'];

if ($password=="admin") {
//berhasil masuk
	//echo "sukses";
	//echo $password_db;
	// session_start();
	// $_SESSION['email']=$email_db;
	// $_SESSION['id_user']=$id_user;
	
	// // echo $nama_db;

	header ('location: admin/admin_home.php');
}
else if($password==$password_db){
session_start();
	$_SESSION['email']=$email_db;
	$_SESSION['id_user']=$id_user;
	
	// echo $nama_db;

	header ('location: home.php');
}
else{
//gagal masuk
//echo "gagal";
	echo $password_db;
	header ('location: loggin.php');
}	
?>