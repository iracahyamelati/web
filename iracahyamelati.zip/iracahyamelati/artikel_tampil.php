<?php
session_start();
include('konekksi.php');
include('navbar.php');

// $id_admin=$_SESSION['id_admin'];
?>
<!DOCTYPE html>
<html>
<title> Artikel </title>
<head>
<style>
body{
	background-color: #000;
} 

header{
  background-color:   #000;
}
h1 {
	font-family: Century Gothic;
  font-size: 50px;
  color : #000;

}
h2 {
  font-family: Century Schoolbook; 
  font-size: 30px;
  color : white;

}
p{
  font-family: Century Schoolbook;
  color: white;
  font-size: 15px;
}
div.container {
    width: 100%;
    border: 0px solid grey;
}

header, footer {
    padding: 1em;
    color: white;
    clear: left;
    text-align: left;

}
article {
    margin-left: 0px;
    border-left: 0px solid gray;
    padding: 1em;
    overflow: hidden;
    color:white;
}}
</style>
</head>
</html>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel=stylesheet href="css/bootstrap.min.css">
    <link rel=stylesheet href="bootstrap-override.css">
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
  <script src-fluid-fluid="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<body>
<br>
<br>
<br>
<br>
<div class="container-fluid">
    <div class="content-wrapper">	
		<div class="item-container">	
			<div class="container">	
				<div class="col-md-14">

				<?php

$artikel=mysql_query("SELECT * FROM artikel");
echo "<table class='table table-responsive'>";
echo "<tr>";
echo" <th>id Artikel</th>";
echo "<th>Judul</th>";
echo "<th>Isi Artikel</th>";
echo "<th>View</th>";


while($data_artikel=mysql_fetch_array($artikel)){
		$id_artikel=$data_artikel['id_artikel'];
		$judul_artikel=$data_artikel['Judul'];
		$isi_artikel=$data_artikel['Isi Artikel'];
		
echo "<tr>";
echo "<td>".$id_artikel."</td>";
echo "<td>".$judul_artikel."</td>";
echo "<td>".$isi_artikel."</td>";

echo "<td><a href ='artikel_detail.php?id=".$id_artikel."'>View</a></td>	";

echo "</tr>";
}
echo "</table>";




?>

</div>
</div>
</div>
</div>
</div>