<<?php 
include ('navbar.php');
 ?>
<!DOCTYPE html>
<html>
<head>
<style>
body{
background-color: #000;
} 
header{
  background-color:   white;
}
h1 {
  font-family: Century Gothic;
  font-size: 50px;
  color : #000;

}
h2 {
  font-family: Century Schoolbook; 
  font-size: 30px;
  color : white;

}
p{
  font-family: Century Schoolbook;
  color: white;
  font-size: 15px;
}
div.container {
    width: 100%;
    border: 0px solid grey;
}

header, footer {
    padding: 1em;
    color: white;
    clear: left;
    text-align: left;

}
/*ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: white;
}
li {
  float: left;


}
li a{
  display: block;
  color: rgb(102, 102, 255);
  text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}


li a:hover {
    background-color: skyblue;
}*/
article {
    margin-left: 0px;
    border-left: 0px solid gray;
    padding: 1em;
    overflow: hidden;
    color:white;
}}



</style>
</head>
<body>

<!-- <div class="container">

<header>
   <h1><center width="850" height="50">Selamat Datang di Website Desa Talunamba</center></h1>
</header> -->

<!-- <nav>

  <ul>
    <li><a href="home.php">Beranda</a></li>
    <li><a href="galery.php">Gallery Kegiatan Warga</a></li>
    <li><a href="tentangdesa.php">Tentang Desa</a></li>
     <li style="float: right;"><a href="logout.php">Keluar</a></li>
<li style="float: right;"><a href="aboutme.php">About Me</a></li>

  </ul>
</nav> -->


<article>
 <right> <h2>Mengenal Lebih dekat Desa Talunamba</h2>  </right> </style>

<center> <img src="webstatis\17.jpg" height=440px width=500px"> </center></style>
  <center> <h4>ket.gambar : Perangkat Desa Talunamba</h4> </center>

  <h3> Urutan Pemerintahan Desa Talunamba Sejak Awal Berdiri</h3>
<p>1. Arsa Manggala (--)
<p>2. Wangsa Wikarta(..-1945</p>
<p>3. Pawira Sudarmo(1945-1971)
<p>4. Prapto Sudarmo(1971-1989)
<p>5. Taryono       (1989-1999)
<p>6. Subahrun      (1999-2007)
<p>7.Taryono        (2007-2013)
<p>8. Suntoro       (2013-2019) 
</p>

<h3>Keadaan dan Kondisi Geografis Desa Talunamba</h3>
<p>Secara administratif Desa Talunamba terletak di Kecamatan Madukara Kabupaten Banjarnegara yang terdiri dari 3 Dusun/RW dan 12 RT. Secar Geografis dan Administratif Desa Talunamba merupakan salah satu dari 266 desa di Banjarnegara,dan memiliki luas 209,753ha. Secara Tropografis terletak pada ketinggian 500 meter dari permukaaan air laut.</p>
<h3>Jumlah Penduduk</h3>
<p>Berdasarkan Profil tahun 2015 jumlah penduduk Desa Talunamba sebesar 1.707 jiwa yang terdiri dari 844 laki-laki dan 863 perempuan.</p>
<h3>Lembaga Kemasyarakatan Desa Talunamba</h3>
<p>1.LP3M
<p>2. PKK
<p>3. Karang Taruna
</p>

</article>

<footer></footer>


</div>

</body>
</html>