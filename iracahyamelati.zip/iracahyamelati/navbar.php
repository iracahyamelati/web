<!DOCTYPE html>
<html lang="en">
<head>
  <title>Web Desa Talunamba</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>

<body>

   
<div class="container" style="width: 100%;">
  <header >
   <h1><center>Website Desa Talunamba</center>
   </h1>
   
</header>
<!-- <div class="row">
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav">   
                <li><a href="barang.php">Home  <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-home"></span></a></li>
                <li><a href="keranjang.php">Keranjang  <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-shopping-cart"></span></a></li>
                <li><a href="tagihan.php">Tagihan  <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-coins"></span></a></li>
                <li><a href="profil.php">Profil  <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-user"></span></a></li>
                <li><a href="logout.php">Log Out  <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-off"></span></a></li>
          </ul>
        </div>
      </div> -->
 <!--  </div> -->

 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
<!--       <a class="navbar-brand" href="barang.php">BlueRed</a>
 -->    </div>
     <ul class="nav navbar-nav">   
                <li><a href="home.php">Home  <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-home"></span></a></li>
               <!--  <li><a href="galery.php">Gallery  <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon"></span></a></li> -->
                <li><a href="artikel_tampil.php">Artikel <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-book"></span></a></li>
                <li><a href="tentangdesa.php">Tentang Desa  <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-coins"></span></a></li>
                <li><a href="aboutme.php">About Me  <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-user"></span></a></li>

                         </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="logout.php">Log Out  <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-off"></span></a></li>

    </ul>
  </div>
</nav>
</div> 
</body>
</html>