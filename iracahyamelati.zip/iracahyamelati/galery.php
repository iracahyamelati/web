<<?php 
include ('navbar.php');
 ?>
 <!DOCTYPE html>
<html>
<head>
<style>
body{
	background-color: black;
} 
h1 {
	font-family: Century Gothic;
}
div.container {
    width: 100%;
    border: 0px solid grey;
}

header, footer {
    padding: 1em;
    color: white;
    clear: left;
    text-align: left;

}
/*ul {
	list-style-type: none;
	margin: 0;
	padding: 0;
	overflow: hidden;
	background-color: black;
}
li {
	float: left;
}
li a{
	display: block;
	color: white;
	text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}


li a:hover {
    background-color: grey;
}*/
article {
    margin-left: 170px;
    border-left: 0px solid gray;
    padding: 1em;
    overflow: hidden;
    color: white;

}
right{
  color:white;
}
div.img {
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    width: 180ppx;
    color: rgb(41, 61, 61);
    font-size: 15px;
    background-color: white;
} 

div.img:hover {
    border: 1px solid #777;
}

div.img img {
    width: 300px;
    height: 200px;
}

div.desc {
    padding: 5px;
    text-align: center;
    font-family: Freestyle Script;
    font-size: 25px;
}

</style>
</head>
<body>

<header>
    <h1><marquee width="850" height="50">Dokumentasi Kegiatan Di Desa Talunamba</marquee></h1>
</header>

<!-- <nav>
  <ul>
    <li><a href="home.php">Beranda</a></li>
    <li><a href="galery.php">Gallery Kegiatan Warga</a></li>
    <li><a href="tentangdesa.php">Tentang Desa</a></li>
    <li style="float: right;"><a href="logout.php">Keluar</a></li>
    <li style="float: right;"><a href="aboutme.php">About Me</a></li>

  </ul>
</nav> -->
<article> 
 
</article>
 
 <div class="img">
  <a target="_blank" href="Parade.jpg">
    <img src="webstatis\Parade.jpg" width="500" height="200">
  </a>
  <div class="desc">Meramaikan Parade Budaya</div>
</div>

<div class="img">
  <a target="_blank" href="penampilan.jpg">
    <img src="webstatis\penampilan.jpg" width="600" height="400">
  </a>
  <div class="desc">Penampilan Kesenian Kuda Kepang</div>
</div>

<div class="img">
  <a target="_blank" href="penabuh.jpg">
    <img src="webstatis\penabuh.jpg" width="600" height="400">
  </a>
  <div class="desc">Para Penabuh Gamelan Kuda Kepang</div>
</div>

<div class="img">
  <a target="_blank" href="latihan.jpg">
    <img src="webstatis\latihan.jpg"  width="600" height="400">
  </a>
  <div class="desc">Latihan Rutin </div>
</div>

<div class="img">
  <a target="_blank" href="DSC05915.JPG">
    <img src="webstatis\DSC05915.JPG"  width="600" height="400">
  </a>
  <div class="desc">Anggota LINMAS Desa Talunamba</div>
</div>

<div class="img">
  <a target="_blank" href="DSC01804.JPG">
    <img src="webstatis\DSC01804.JPG"  width="600" height="400">
  </a>
  <div class="desc">Kegiatan Gotong Royong(1)</div>
</div>

<div class="img">
  <a target="_blank" href="DSC01812.JPG">
    <img src="webstatis\DSC01812.JPG"  width="600" height="400">
  </a>
  <div class="desc">Kegiatan Gotong Royong (2)</div>
</div>

<div class="img">
  <a target="_blank" href="DSC04606.JPG">
    <img src="webstatis\DSC04606.JPG"  width="600" height="400">
  </a>
  <div class="desc">Rehab Aspal Dukuh Sipedang</div>
</div>

<div class="img">
  <a target="_blank" href="DSC06083.JPG">
    <img src="webstatis\DSC06083.JPG"  width="600" height="400">
  </a>
  <div class="desc">Benner Kegiatan</div>
</div>

<div class="img">
  <a target="_blank" href="DSC06134.JPG">
    <img src="webstatis\DSC06134.JPG"  width="600" height="400">
  </a>
  <!-- <div class="desc">Para Peserta Ujian SEKDES</div>
</div>

<div class="img">
  <a target="_blank" href="DSC06130.JPG">
    <img src="webstatis\DSC06130.JPG"  width="600" height="400">
  </a>
  <div class="desc">Para Peserta sedang melakukan ujian</div>
</div>

<div class="img">
  <a target="_blank" href="DSC06152.JPG">
    <img src="webstatis\DSC06152.JPG"  width="600" height="400">
  </a>
  <div class="desc">Foto Bersama</div>
</div>

<div class="img">
  <a target="_blank" href="DSC00942.JPG">
    <img src="webstatis\DSC00942.JPG"  width="600" height="400">
  </a>
  <div class="desc">Anggota PKK RT 01/01</div>
</div>

<div class="img">
  <a target="_blank" href="IMG_0067%20-%20Copy.JPG">
    <img src="webstatis\IMG_0067%20-%20Copy.JPG"  width="600" height="400">
  </a>
  <div class="desc">Anggota PKK RT 02/01</div>
</div>

<div class="img">
  <a target="_blank" href="1502781577748.jpg">
    <img src="webstatis\1502781577748.jpg"  width="600" height="400">
  </a>
  <div class="desc">Anggota PKK RT 03/01</div>
</div>

<div class="img">
  <a target="_blank" href="1502718882617.jpg">
    <img src="webstatis\1502718882617.jpg"  width="600" height="400">
  </a>
  <div class="desc">Penampilan Anggota PKK RT 03/02</div>
</div>

<div class="img">
  <a target="_blank" href="DSC01514.JPG">
    <img src="webstatis\DSC01514.JPG"  width="600" height="400">
  </a>
  <div class="desc">Susunan Kepengurusan Posyandu</div>
</div>

<div class="img">
  <a target="_blank" href="DSC01523.JPG">
    <img src="webstatis\DSC01523.JPG"  width="600" height="400">
  </a>
  <div class="desc">Kegiatan Posyandu</div>
</div>

<div class="img">
  <a target="_blank" href="DSC01525.JPG">
    <img src="webstatis\DSC01525.JPG"  width="600" height="400">
  </a>
  <div class="desc">Penyuluhan Kesehatan Anak</div>
</div>

<div class="img">
  <a target="_blank" href="DSC01535.JPG">
    <img src="webstatis\DSC01535.JPG"  width="600" height="400">
  </a>
  <div class="desc">Kegiatan Timbangan Anak</div>
</div>

<div class="img">
  <a target="_blank" href="DSC00184.JPG">
    <img src="webstatis\DSC00184.JPG"  width="600" height="400">
  </a>
  <div class="desc">Halal Bihalal</div>
</div>

<div class="img">
  <a target="_blank" href="DSC00172.JPG">
    <img src="webstatis\DSC00172.JPG"  width="600" height="400">
  </a>
  <div class="desc">Musyawarah Desa</div>
</div>

<div class="img">
  <a target="_blank" href="f0770176.jpg">
    <img src="webstatis\f0770176.jpg"  width="600" height="400">
  </a>
  <div class="desc">Pelantikan BPD 2016 (1)</div>
</div>

<div class="img">
  <a target="_blank" href="f0921536.jpg">
    <img src="webstatis\f0921536.jpg"  width="600" height="400">
  </a>
  <div class="desc">Pelantikan BPD 2016 (2)</div>
</div>

<div class="img">
  <a target="_blank" href="IMG_0046.JPG">
    <img src="webstatis\IMG_0046.JPG"  width="600" height="400">
  </a>
  <div class="desc">Puncak HUT RI ke-72</div>
</div>

<div class="img">
  <a target="_blank" href="IMG_0026.JPG">
    <img src="webstatis\IMG_0026.JPG"  width="600" height="400">
  </a>
  <div class="desc">Jalan Sehat dalam Rangka HUT RI</div>
</div>

<div class="img">
  <a target="_blank" href="DSC00214.JPG">
    <img src="webstatis\DSC00214.JPG"  width="600" height="400">
  </a>
  <div class="desc">Lomba HUT RI</div>
</div>

<div class="img">
  <a target="_blank" href="DSC00373.JPG">
    <img src="webstatis\DSC00373.JPG"  width="600" height="400">
  </a>
  <div class="desc">Jalan Sambung dalam Rangka HUT RI</div> -->
</div>

<div class="container">



<footer></footer>


</div>

</body>
</html>