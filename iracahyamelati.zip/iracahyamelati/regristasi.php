 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>


<div class="centerY">
   <form class="centerY" action="regristasi_proses.php" method="post" style="background:white; width: 50%">
    <h1 align="center" style="font-weight:normal">Regristasi <!-- <span style="color:black;background:rgb(70, 210, 168);padding:5px;width:100px;height:100px;"> <i class="fa fa-arrow-right"></i> --></span></h1>
        <input type="text" placeholder="Email" name="email" value="">
        <input type="text" placeholder="Password" style="margin-bottom:0!important" name="password" value="">
    <input type="text" placeholder="Nama" style="margin-bottom:0!important" name="nama" >
      <center> <div class="input-group" >     
            <input type="submit" class="btn btn-primary" value="     SAVE                       " >
          </div></center>
       
    <!-- <div class="form-wrap" style="margin: auto; text-align: center; width: 50%;">
         <center><h1>LOGIN USER</h1></center>
    <div class="form-group"> -->
   <!--  <?php

// echo '<form action="login_proces.php" method="POST">';
// echo '<input type="text" name="email" placeholder="Email"  class="form-control"><br><br>';
// echo '<input type="password" name="password" placeholder="Password"  class="form-control"><br><br>';
// echo '<input type="submit" name="login" class="btn btn-primary btn-lg btn-block" value="login">';
// echo '</form>';
    
?> -->
</form>
</div>