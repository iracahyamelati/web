<?php 
include 'konekksi.php';
include 'navbar.php';
?>


<h3><span class="glyphicon glyphicon-book"></span> Artikel</h3>

<?php
$id=mysql_real_escape_string($_GET['id']);


$det=mysql_query("select * from artikel where id_artikel='$id'")or die(mysql_error());
while($d=mysql_fetch_array($det)){

 echo $d['Judul'];
 echo"<br>";
 echo $d['Isi Artikel'];
}
	?>	

	<br><a class="btn" href="artikel_tampil.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
