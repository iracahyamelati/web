<<?php 
include ('navbar.php');
 ?>
<!DOCTYPE html>
<html>
<head>
<style>
body{
	background-color: black;
} 
h1 {
	font-family: Bakery;
}
div.container {
    width: 100%;
    border: 0px solid grey;
}

header, footer {
    padding: 1em;
    color: white;
    clear: left;
    text-align: left;

}
ul {
	list-style-type: none;
	margin: 0;
	padding: 0;
	overflow: hidden;
	background-color: black;
}
li {
	float: left;
}
li a{
	display: block;
	color: white;
	text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}


li a:hover {
    background-color: black;
}
article {
    margin-left: 0px;
    border-left: 0px black;
    padding: 1em;
    overflow: hidden;
}
h1 {
  color: white;
  font-family: Bakery;
  font-size: 40px;
}
p{
  font-family: Bakery;
  color: white;
  font-size: 25px;
}
</style
</head>
<body>


<div class="container">
*/
<header>
   <h1>About Me</h1>
</header>




<article>
  <center><h1>Profil Penulis </h1></center></style>
  <center><img src="webstatis\pict.jpg" height=350px width=450px;></style>
  <p>Holaaa!!! Perkenalkan Nama Saya Ira Cahya Melati </p>
  <p>Lahir di Banjarnegara,26 Mei 2002</p>
  <p>Alamat : Desa Talunamba RT 02/01</p>
  <p>Sekolah : SMKN 1 BAWANG</p>
  <p>Kompetensi Keahlian : Rekayasa Perangkat Lunak</p>
  <p>Email : iracahyamelati05@gmail.com</p>
  <p>Instragram : @iraaachyyy_</p>
  <p>WhatsApp : 083863418495</p>
  <p>Semoga dengan adanya web ini dapat bermanfaat ^_^</p>
</article>

<footer></footer>


</div>

</body>
</html>