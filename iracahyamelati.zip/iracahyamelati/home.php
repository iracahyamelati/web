<<?php 
include ('navbar.php');
 ?>
<!DOCTYPE html>
<html>
<head>
<style>
body{
background-color: #000;
} 
header{
  background-color:   white;
}
h1 {
	font-family: Century Gothic;
  font-size: 50px;
  color : #000;

}
h2 {
  font-family: Century Schoolbook; 
  font-size: 30px;
  color : white;

}
p{
  font-family: Century Schoolbook;
  color: white;
  font-size: 15px;
}
div.container {
    width: 100%;
    border: 0px solid grey;
}

header, footer {
    padding: 1em;
    color: white;
    clear: left;
    text-align: left;

}
/*ul {
	list-style-type: none;
	margin: 0;
	padding: 0;
	overflow: hidden;
	background-color: white;
}
li {
	float: left;


}
li a{
	display: block;
	color: rgb(102, 102, 255);
	text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}


li a:hover {
    background-color: skyblue;
}*/
article {
    margin-left: 0px;
    border-left: 0px solid gray;
    padding: 1em;
    overflow: hidden;
    color:white;
}}



</style>
</head>
<body>

<!-- <div class="container">

<header>
   <h1><center width="850" height="50">Selamat Datang di Website Desa Talunamba</center></h1>
</header> -->

<!-- <nav>

  <ul>
    <li><a href="home.php">Beranda</a></li>
    <li><a href="galery.php">Gallery Kegiatan Warga</a></li>
    <li><a href="tentangdesa.php">Tentang Desa</a></li>
     <li style="float: right;"><a href="logout.php">Keluar</a></li>
<li style="float: right;"><a href="aboutme.php">About Me</a></li>

  </ul>
</nav> -->


<article>
 <center> <h2>Sekilas Tentang Desa Talunamba</h2> </center> </style>

<center> <img src="webstatis\struktur organisasi.jpg" height=650px width=800px"> </center></style>
  <center> <h3>ket.gambar : Perangkat Desa Talunamba</h3> </center>

  <h3>Desa Talunamba adalah Desa yang terletak di Kecamatan Madukara,Kabupaten Jawa Tengah.</h3>
  <b><p>VISI MISI Desa Talunamba</b>

<b><p> Visi </p>
<b><p>Terwujudnya Desa Talunamba yang mandiri dan sejahtera.

<b><p> Misi </p>
<b><p>1. Mewujudkan keamanan nasional yang mampu menjaga kedaulatan wilayah, menopang kemandirian ekonomi dengan mengamankan sumber daya maritim, dan mencerminkan kepribadian Indonesia sebagai negara kepulauan.
<b><p>2. Mewujudkan masyarakat maju, berkeseimbangan, dan demokratis berlandaskan negara hukum.
<b><p>3. Mewujudkan politik luar negeri bebas-aktif dan memperkuat jati diri sebagai negara maritim.
<b><p>4. Mewujudkan kualitas hidup manusia Indonesia yang tinggi, maju, dan sejahtera.
<b><p>5. Mewujudkan bangsa yang berdaya saing.
<b><p>6. Mewujudkan Indonesia menjadi negara maritim yang mandiri, maju, kuat, dan berbasiskan kepentingan nasional.
<b><p>7. Mewujudkan masyarakat yang berkepribadian dalam kebudayaan.
</b>
</p>
</article>

<footer></footer>


</div>

</body>
</html>