<!DOCTYPE html>
<html>


<head>
<head>
  <title>WEBDESATALUNAMBA</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <style media="screen">
      * {
        padding: 0;
        margin: 0;
      }
      body{
      }
      div{
        margin: auto;
        width: 600px;
        background: white;
        height: 400px!important;
      }
      form{
        width: 100%!important;
      }
      input{
        width: 50%!important;
        margin: 30px auto!important;
      }
    </style>
	<title>LOGIN</title>
</head>
<body>

<div class="centerY">
   <form class="centerY" action="loggin_proces.php" login=true" method="post" style="background:white;">
    <h1 align="center" style="font-weight:normal">LOGIN <!-- <span style="color:black;background:rgb(70, 210, 168);padding:5px;width:100px;height:100px;"> --> <!-- <i class="fa fa-arrow-right"></i> --></span></h1>
        <input type="text" placeholder="Email" name="email" value="">
        <input type="password" placeholder="Password" style="margin-bottom:0!important" name="password" value="">
        <p style="text-align:center;padding:20px;font-size:8pt;opacity:0.6"><a href ="regristasi.php"> Buat Akun ?<a/></p>
          <center> <div class="input-group">     
            <input type="submit" class="btn btn-primary" value="Login" >
          </div></center>
       
    <!-- <div class="form-wrap" style="margin: auto; text-align: center; width: 50%;">
         <center><h1>LOGIN USER</h1></center>
    <div class="form-group"> -->
   <!--  <?php

// echo '<form action="login_proces.php" method="POST">';
// echo '<input type="text" name="email" placeholder="Email"  class="form-control"><br><br>';
// echo '<input type="password" name="password" placeholder="Password"  class="form-control"><br><br>';
// echo '<input type="submit" name="login" class="btn btn-primary btn-lg btn-block" value="login">';
// echo '</form>';
    
?> -->
</form>
</div>

</body>

</html>