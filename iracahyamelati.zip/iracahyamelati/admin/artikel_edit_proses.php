<?php 
include 'konekksi.php';
$id=$_POST['id'];
$judul=$_POST['judul'];
$isi=$_POST['isi'];
// echo $id;
// echo $judul;
// echo $isi;
mysql_query("UPDATE `artikel` SET `Judul`='$judul',`Isi Artikel`='$isi' WHERE id_artikel = '$id'");
header("location:admin_artikel.php");

?>
