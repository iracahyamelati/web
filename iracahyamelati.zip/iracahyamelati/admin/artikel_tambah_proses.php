<?php 
include 'konekksi.php';

$judul=$_POST['judul'];
$isi=$_POST['isi'];
// echo $id;
echo $judul;
echo $isi;
mysql_query("INSERT INTO `artikel`( `Judul`, `Isi Artikel`) VALUES ('$judul','$isi')");
header("location:admin_artikel.php");

?>
