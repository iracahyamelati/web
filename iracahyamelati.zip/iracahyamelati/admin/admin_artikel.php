<?php
session_start();
include('konekksi.php');

include('navbar.php');

// $id_admin=$_SESSION['id_admin'];
?>
<!DOCTYPE html>
<html>

<title> Artikel </title>

<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel=stylesheet href="css/bootstrap.min.css">
    <link rel=stylesheet href="bootstrap-override.css">
    <!-- <link rel="stylesheet" href="artikelstyle.css"> -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
  <script src-fluid-fluid="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<body>
<br>
<br>
<br>
<br>
<div class="container-fluid">
    <div class="content-wrapper">	
		<div class="item-container">	
			<div class="container">	
				<div class="col-md-14">

				<?php

$artikel=mysql_query("SELECT * FROM artikel");
echo "<table class='table table-responsive'>";
echo "<tr>";
echo" <th>id Artikel</th>";
echo "<th>Judul</th>";
echo "<th>Isi Artikel</th>";


while($data_artikel=mysql_fetch_array($artikel)){
		$id_artikel=$data_artikel['id_artikel'];
		$judul_artikel=$data_artikel['Judul'];
		$isi_artikel=$data_artikel['Isi Artikel'];
		
echo "<tr>";
echo "<td>".$id_artikel."</td>";
echo "<td>".$judul_artikel."</td>";
echo "<td>".$isi_artikel."</td>";
echo "<td><a href ='artikel_edit.php?id=".$id_artikel."'  class='btn btn-warning'>EDIT</a></td>	";
echo "<td><a href ='artikel_hapus.php?id=".$id_artikel."'  class='btn btn-danger'>HAPUS</a></td>";	
echo "</tr>";
}
echo "</table>";




?>
<a href= "admin_home.php">Back <a/>
</div>
</div>
</div>
</div>
</div>