<?php 
include 'konekksi.php';
$id=$_GET['id'];
mysql_query("delete from Artikel where id_artikel='$id'");
header("location:admin_artikel.php");

?>