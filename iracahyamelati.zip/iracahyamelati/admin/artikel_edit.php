<?php 
 include 'konekksi.php';
?>
<style >
	
	.form{
  margin-left: 170px;
}

</style>
<h3><span class="glyphicon glyphicon-briefcase"></span>  Edit Artikel</h3>
<!-- <a class="btn" href="barang_laku.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a> -->

<?php
$id=mysql_real_escape_string($_GET['id']);

$det=mysql_query("select * from artikel where id_artikel='$id'")or die(mysql_error());
while($d=mysql_fetch_array($det)){
  ?>          
  <form action="artikel_edit_proses.php" method="post">
  
       <input type="hidden" name="id" value="<?php echo $d['id_artikel'] ?>">
      Judul
      <textarea name="judul" type="text" class="form-control" value="<?php echo $d['Judul'] ?>"> </textarea><br>Isi
      <textarea type="text" class="form-control" name="isi" value="<?php echo $d['Isi Artikel'] ?>"></textarea>
     <input type="submit" class="btn btn-info" value="Simpan">
  </form>
  <?php 
}
?>
