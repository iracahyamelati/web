<?php
if (isset($conn) > 0) {
  echo "
      <script>
        alert('berhasil');
        document.link.href='form.php';
      </script>
  ";
}else {

}

 ?>
<!DOCTYPE html>
<html>
<head>
<title>Web Desa Talunamba.com</title>
</head>
<style>
div.container {
    width: 100%;
}

header,footer {
    padding: 0;
    color: white;
    background-color: skyblue;
    clear: left;
    text-align: center;
    width:100%;
    height:auto;
}

nav {

    max-width: 160px;
    margin: 0;
    padding: 0;
}

nav ul {
    list-style-type: none ;
    padding: 0;
}

nav ul a {
    text-decoration: none ;
}



p{
color : white;
}
h1{
color : white;
text-shadow: 2px 2px 5px black ;
}
h2{
color : black;
}
footer{
color : white;
}
body{
  overflow-x: hidden;
}
/* RESET */  html, body, div, span, applet, object, iframe,  h1, h3, h2, h3, h4, h5, h6, p, blockquote, pre,  a, abbr, acronym, address, big, cite, code,  del, dfn, em, font, img, ins, kbd, q, s, samp,  small, strike, strong, sub, sup, tt, var,  b, u, i, center,dl, dt, dd, ol, ul, li,  fieldset, form, label, legend,  table, caption, tbody, tfoot, thead, tr, th, td {   margin: 0; padding: 0; outline: 0; fontsize: 100%;   vertical-align: baseline; background: transparent;   height: auto; border-top-width: 0;   border-bottom-width: 0; border-left-width: 0;}  blockquote:before, blockquote:after,q:before, q:after {content: none;}
 blockquote, q {quotes: none;}  :focus {outline: 0;}  .clear {clear: both;display: block;height: 1px;overflow: hidden;margin: 0;padding: 0;}  ins {text-decoration: none;}  del {text-decoration: line-through;}  table {border-collapse: collapse;border-spacing: 0;}  ol, ul {list-style: none;}  ol, ul {list-style: none;}  body {background-color: #ffffff;backgroundposition: center center;}  /* RESET */

 #menu ul li a{
    color:skyblue;
    text-decoration:none;
    padding:0px 5px 0px 5px;/*memberi jarak antar teks*/
    font:15pt cambria;/*mengatur format teks dgn size 15pt dan jns font cambria*/
    font-weight:bold;  }
           #menu ul li a:hover{
            color:white;   background-color:skyblue;
              }
            #menu ul li{
            display:inline;/*membuat tampilan list sejajar ke samping*/
            padding:0px 2px 0px 2px;
}

div.cities {
    background-color:lightblue;
    color:black;
    margin:20px;
    padding:20px;
    max-width:100%;

}

.form{
  margin-left: 170px;
}

.tulisan{
  color: white;
}

.ratna{
  width:auto;
  height:auto;
}
</style>

<body>

<div class="container">

<header>
   <h1 style="font-size:50px;"><font face="Century Gothic" ><center>WEB DESA TALUNAMBA</h1></h1></center>
</header>


  <div id="menu">
  <ul>
  <center>
    <li color="white"><a href="home.php" class="current">Home</a></li>
    <li><a href="galery.php">Galery</a></li>
    <li><a href="tentangdesa.php">Lebih dekat Dengan Desa Talunamba</a></li>
    <li><a href="aboutme.php">About Me</a></li>
<!--     <li><a href="Aud.html">Audio</a></li>
    <li><a href="Desa.html">Tentang Desa</a></li> -->
  
    <li><a href="artikel.php">Artikel</a></li>
      <li><a href="Form.php">Form</a></li>
    </div>
  </center>
  </ul>

  <img src="banjarmangu.PNG" class="ratna">

 <h2 style="font-size:30px;margin-left :170px;"  >Buat Artikel</h2><br>
  <div>

  <form class="form" action="buat_artikel.php" method="post">

    <textarea name="message" rows="3" cols="70" autofocus required placeholder="Judul" margin-left:170px;
    ></textarea>
  <br>

    <textarea name="Tulis Artikel" rows="30" cols="100" placeholder="Tulis Artikel" margin-left:170;></textarea>
    <br>
    <input type="submit">
  </form>
</div>







<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

  </body>
  </html>
