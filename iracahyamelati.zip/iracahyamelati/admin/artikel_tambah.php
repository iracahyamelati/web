<?php 
 include 'konekksi.php';
?>

<h3><span class="glyphicon glyphicon-briefcase"></span>  Tambah Artikel</h3>
<!-- <a class="btn" href="barang_laku.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a> -->
         
  <form action="artikel_tambah_proses.php" method="post">
  
      Judul
      <input name="judul" type="text" class="form-control" value="">
      <br>Isi
      <input type="text" class="form-control" name="isi" value="">
     <input type="submit" class="btn btn-info" value="Simpan">
  </form>
 
